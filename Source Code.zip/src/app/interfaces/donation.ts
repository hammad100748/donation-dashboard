export interface Donation {    
    id?:string;  
    sur?:string;
    name?:string;
    amount?:number;
    category?:string;
    createdAt?:any;
}
