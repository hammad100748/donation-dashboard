export const environment = {
  production: true,  
  // firebase:{
  //   apiKey: "AIzaSyDEPr_zEO4a7AuxwwZ7ctBn43HicNKpF50",
  //   authDomain: "donations-35fab.firebaseapp.com",
  //   databaseURL: "https://donations-35fab.firebaseio.com",
  //   projectId: "donations-35fab",
  //   storageBucket: "",
  //   messagingSenderId: "371272111686"
  // }
  firebase:{
    apiKey: "AIzaSyCgpCG5eiPPmg1JteshAGwRwiiCLZ5j3lw",
    authDomain: "donation-local.firebaseapp.com",
    databaseURL: "https://donation-local.firebaseio.com",
    projectId: "donation-local",
    storageBucket: "",
    messagingSenderId: "867770145837"
  }
};
