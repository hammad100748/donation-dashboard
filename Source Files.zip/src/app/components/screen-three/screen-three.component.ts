import { Component, OnInit } from '@angular/core';
import { Project } from '../../interfaces/project';
import { FirestoreService } from '../../services/firestore.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-screen-three',
  templateUrl: './screen-three.component.html',
  styleUrls: ['./screen-three.component.css']
})
export class ScreenThreeComponent implements OnInit {
  currentProject:Project;
  project:Project;
  numCat;
  font_size;
  x='$';
  constructor(private _fireStore:FirestoreService,private _sanitizer: DomSanitizer) { }
 
  ngOnInit() {
    this.currentProject=JSON.parse(localStorage.getItem('project')); 
    this._fireStore.getCurrentProject(this.currentProject.id)
    .subscribe((project)=>{
      if(project){
        console.log(project);
        this.project=project;
      }else{ 
        this.project.category1Total=0; 
        this.project.category2Total=0;
        this.project.category3Total=0;
        this.project.category4Total=0;
      }
      if(this.currentProject.categories.length===3){
        this.numCat=4;
        this.font_size='48px';
      }else if(this.currentProject.categories.length===4){
        this.numCat=3;
        this.font_size='36px'
      }else if(this.currentProject.categories.length===2){
        this.numCat=6;
        this.font_size='72px'
      }else{
        this.numCat=6;
        this.font_size='82px'
      }
    });
  }

  getBackground(image) {
    return this._sanitizer.bypassSecurityTrustStyle(`linear-gradient(rgba(29, 29, 29, 0), rgba(16, 16, 23, 0.5)), url(${image})`);
  }

} 
