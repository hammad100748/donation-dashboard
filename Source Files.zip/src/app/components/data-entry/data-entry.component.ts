import { Component, OnInit } from '@angular/core';
import { Project } from '../../interfaces/project';
import { Donation } from '../../interfaces/donation';
import { FirestoreService } from '../../services/firestore.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';

@Component({
  selector: 'app-data-entry',
  templateUrl: './data-entry.component.html',
  styleUrls: ['./data-entry.component.css']
})
export class DataEntryComponent implements OnInit {

  donation: Donation;
  categories: string[];
  project: Project;
  total_donation = 0;
  model;
  constructor(private _fireStore: FirestoreService,
    private spinnerService: Ng4LoadingSpinnerService,
    private _flashMessagesService: FlashMessagesService,
    private _router: Router) {
    this.model = {
      sur: "הרב"
    };
    this.donation = {
      category: '1'
    };
    console.log('here');
  }

  ngOnInit() {
    if (!localStorage.getItem('user')) {
      this._router.navigate(['/']);
      return;
    }
    this.spinnerService.hide();
    this.project = JSON.parse(localStorage.getItem('project'));
    this.categories = this.project.categories;
  }

  changeCategory(value) {
    this.donation.category = value;
  }



  submitDonation(myForm) {
    let values = myForm.value;
    this.donation.projectId = this.project.id;
    this.donation.sur = values.sur;
    this.donation.name = values.name;
    this.donation.amount = values.amount;
    const createdAt = new Date();
    this.donation.createdAt = createdAt;
    // Calculating Total Donation
    this.project.totalDonation += values.amount;
    // Calculating Categories Total
    if (this.donation.category == '1') {
      this.project.category1Total++;
    } else if (this.donation.category == '2') {
      this.project.category2Total++;
    } else if (this.donation.category == '3') {
      this.project.category3Total++;
    } else if (this.donation.category == '4') {
      this.project.category4Total++;
    }
    this.spinnerService.show();
    this._fireStore.addDonation(this.donation)
      .then((docRef) => {
        console.log('Donation Added');
        console.log(this.donation);
        this.updateCurrentDonation();
        myForm.reset({ sur: "הרב", category: '1' });
      });
  }

  updateCurrentDonation() {
    this._fireStore.updateCurrentDisplayDonation(this.donation).then(() => {
      console.log('Update Current donation');
      this.updateProject()
    });
  }

  updateProject() {
    this._fireStore.updateProject(this.project).then(() => {
      console.log('Project Updated');
      this._flashMessagesService.show('Donation Added!', { cssClass: 'alert-success', timeout: 2000 });
      localStorage.setItem('project', JSON.stringify(this.project));
      this.spinnerService.hide();
      this.donation = {};
      this.donation.category = '1';
      this.model = {
        sur: "הרב"
      };
    });
  }

}
