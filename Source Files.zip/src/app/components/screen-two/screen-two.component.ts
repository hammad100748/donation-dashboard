import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FirestoreService } from '../../services/firestore.service';
import { Donation } from '../../interfaces/donation';
import { Project } from '../../interfaces/project';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-screen-two',
  templateUrl: './screen-two.component.html',
  styleUrls: ['./screen-two.component.css']
})
export class ScreenTwoComponent implements OnInit {

  constructor(private _fireStore:FirestoreService,private _sanitizer: DomSanitizer) { }
  donation:Donation={
    name:'',
    amount:0
  };
  currentProject:Project;
  project:Project;
  category1Donations:Donation[];
  category2Donations:Donation[];
  category3Donations:Donation[];
  category4Donations:Donation[];
  numCat;
  ngOnInit() {
    this.currentProject=JSON.parse(localStorage.getItem('project'));        
    this._fireStore.getCurrentDonation()
    .subscribe((donation)=>{
      if(donation)
      this.donation=donation;
    });
    this._fireStore.getCurrentProject(this.currentProject.id)
    .subscribe((project)=>{
      this.project=project;
      if(this.project.categories.length===3){
        this.numCat=4;
      }else if(this.project.categories.length===4){
        this.numCat=3;
      }else if(this.project.categories.length===2){
        this.numCat=6;
      }else{
        this.numCat=12;
      }
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'1').subscribe((donations)=>{      
        this.category1Donations=donations;
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'2').subscribe((donations)=>{
        this.category2Donations=donations;
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'3').subscribe((donations)=>{
        this.category3Donations=donations;
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'4').subscribe((donations)=>{
        this.category4Donations=donations;        
    });
  }

  getBackground(image) {
    return this._sanitizer.bypassSecurityTrustStyle(`linear-gradient(rgba(29, 29, 29, 0), rgba(16, 16, 23, 0.5)), url(${image})`);
  }

}
