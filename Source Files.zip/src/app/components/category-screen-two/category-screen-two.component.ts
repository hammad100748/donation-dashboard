import { Component, OnInit } from '@angular/core';
import { FirestoreService } from '../../services/firestore.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Donation } from '../../interfaces/donation';
import { Project } from '../../interfaces/project';

@Component({
  selector: 'app-category-screen-two',
  templateUrl: './category-screen-two.component.html',
  styleUrls: ['./category-screen-two.component.css']
})
export class CategoryScreenTwoComponent implements OnInit {

  constructor(private _fireStore:FirestoreService,private _sanitizer: DomSanitizer) { }
  donation:Donation;
  currentProject:Project;
  project:Project;
  category1Donations:Donation[];
  category2Donations:Donation[];
  category3Donations:Donation[];
  category4Donations:Donation[];
  numCat;
  ngOnInit() {
    this.currentProject=JSON.parse(localStorage.getItem('project'));        
    this._fireStore.getCurrentDonation()
    .subscribe((donation)=>{
      this.donation=donation;
    });
    this._fireStore.getCurrentProject(this.currentProject.id)
    .subscribe((project)=>{
      this.project=project;
      if(this.project.categories.length===3){
        this.numCat=4;
      }else if(this.project.categories.length===4){
        this.numCat=3;
      }else if(this.project.categories.length===2){
        this.numCat=6;
      }else{
        this.numCat=12;
      }
      this.filterCategory(this.project.categories,this.donation.category);
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'1').subscribe((donations)=>{
        this.category1Donations=donations;
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'2').subscribe((donations)=>{
        this.category2Donations=donations;
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'3').subscribe((donations)=>{
        this.category3Donations=donations;
    });
    this._fireStore.getCategoryDonations(this.currentProject.id,'4').subscribe((donations)=>{
        this.category4Donations=donations;        
    });
  }

  categorySelected;
  filterCategory(categories,currentCategoryId){
      this.categorySelected=categories.filter(t=>t.id == currentCategoryId);      
  }

  getBackground(image) {
    return this._sanitizer.bypassSecurityTrustStyle(`linear-gradient(rgba(29, 29, 29, 0), rgba(16, 16, 23, 0.5)), url(${image})`);
  }

}
