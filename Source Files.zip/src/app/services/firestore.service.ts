import { Injectable } from '@angular/core';
import { AngularFireAuth, } from 'angularfire2/auth';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap'
import { Router } from '@angular/router';
import { Project } from '../interfaces/project';
import { Donation } from '../interfaces/donation';

@Injectable()
export class FirestoreService {

  constructor(private afAuth: AngularFireAuth, private afs: AngularFirestore, private _router: Router) { 

  }

  login(email,password){
    return this.afAuth.auth.signInWithEmailAndPassword(email, password);
  }

  signOut() {
    this.afAuth.auth.signOut().then(() => {
      this.removeCurrentDonation().then((docRef)=>{
        localStorage.clear();
        this._router.navigate(['/']);
      });
    });
  }

  addProject(project:Project){    
    return this.afs.collection('projects').add(project);
  }

  updateProject(project:Project){
    return this.afs.collection('projects').doc(project.id).update(project);
  }

  addDonation(donation:Donation){    
    return this.afs.collection('donations').add(donation);
  }

  updateCurrentDisplayDonation(donation:Donation){
    return this.afs.collection('currentdonation').doc('current').set(donation);
  }

  getCurrentDonation(){
    return this.afs.collection('currentdonation').doc('current').valueChanges();
  }

  getCurrentProject(project_id){
    return this.afs.collection('projects').doc(project_id).valueChanges();
  }

  getCategoryDonations(project_id,cat){    
    return this.afs.collection('donations',ref => ref.where('projectId', '==', project_id).where('category', '==', cat).orderBy('createdAt','desc').limit(9)).valueChanges();
  }

  getAllDonations(project_id){
    return this.afs.collection('donations',ref => ref.where('projectId', '==', project_id)).valueChanges();
  }

  removeCurrentDonation(){
    return this.afs.collection('currentdonation').doc('current').delete();
  }

}
